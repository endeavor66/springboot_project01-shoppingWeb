package com.zhongruan.bean;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "t_goods")
public class Goods {

    @Id
    @GeneratedValue
    private Long id;
    private String goodsName;   //商品名
    private String description; //描述
    private Float price;    //价格
    private Integer stock;  //库存
    private Integer views;  //浏览量
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;    //上架时间，即成功添加商品时间
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTime;    //更新时间

    @ManyToOne
    private Brand brand;    //所属品牌

    @ManyToMany(cascade = {CascadeType.PERSIST})
    private List<Tag> tagList = new ArrayList<Tag>();   //包含的标签，如：短袖可拥有的标签：男、休闲、潮流

    @OneToMany(mappedBy = "goods")
    private List<Picture> pictureList = new ArrayList<Picture>();

    @OneToMany(mappedBy = "goods")
    private List<Order> orderList = new ArrayList<Order>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Integer getViews() {
        return views;
    }

    public void setViews(Integer views) {
        this.views = views;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public List<Tag> getTagList() {
        return tagList;
    }

    public void setTagList(List<Tag> tagList) {
        this.tagList = tagList;
    }

    public List<Picture> getPictureList() {
        return pictureList;
    }

    public void setPictureList(List<Picture> pictureList) {
        this.pictureList = pictureList;
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "id=" + id +
                ", goodsName='" + goodsName + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", views=" + views +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", brand=" + brand +
                ", tagList=" + tagList +
                ", pictureList=" + pictureList +
                ", orderList=" + orderList +
                '}';
    }
}
