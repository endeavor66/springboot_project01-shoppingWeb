package com.zhongruan.bean;

import org.aspectj.weaver.ast.Or;

import javax.persistence.*;

@Entity
@Table(name = "t_comment")
public class Comment {

    @Id
    @GeneratedValue
    private Long id;

    private String content;

    @ManyToOne
    private Order order;
}
