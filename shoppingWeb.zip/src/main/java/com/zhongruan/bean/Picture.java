package com.zhongruan.bean;

import javax.persistence.*;

@Entity
@Table(name = "t_picture")
public class Picture {

    @Id
    @GeneratedValue
    private Long id;
    private String pictureUrl;

    @ManyToOne
    private Goods goods;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public Goods getGoods() {
        return goods;
    }

    public void setGoods(Goods goods) {
        this.goods = goods;
    }

    @Override
    public String toString() {
        return "Picture{" +
                "id=" + id +
                ", pictureUrl='" + pictureUrl + '\'' +
                ", goods=" + goods +
                '}';
    }
}
