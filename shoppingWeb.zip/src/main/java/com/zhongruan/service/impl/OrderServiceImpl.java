package com.zhongruan.service.impl;

import com.zhongruan.bean.Order;
import com.zhongruan.dao.OrderDao;
import com.zhongruan.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Override
    public Page<Order> findAllOrder(Pageable pageable) {
        return orderDao.findAll(pageable);
    }
}
