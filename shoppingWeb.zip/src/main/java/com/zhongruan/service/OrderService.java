package com.zhongruan.service;

import com.zhongruan.bean.Order;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface OrderService {

    Page<Order> findAllOrder(Pageable pageable);
}
