package com.zhongruan.controller;

import com.zhongruan.bean.Order;
import com.zhongruan.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @RequestMapping("findAllOrder")
    public String findAllOrder(@PageableDefault(size = 5, sort = {"createTime"}, direction = Sort.Direction.DESC)Pageable pageable,
                           Model model){
        Page<Order> page = orderService.findAllOrder(pageable);
        model.addAttribute("page", page);
        return "orderManage";   //返回订单管理主界面-默认全部订单
    }
}
